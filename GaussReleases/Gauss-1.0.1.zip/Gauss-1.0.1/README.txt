#########################################################
#########################################################
#########################################################
#########################################################
#########################################################

				Welcome to Gauss ^_^
				
#########################################################
#########################################################
#########################################################
#########################################################
#########################################################

Please follow the steps below.

If you know you already have Microsoft Visual C++ 
Redistributable for Visual Studio 2017 installed then
skip step 1.

1) Run the vc_redist.x86.exe to install the Microsoft
Visual C++ Redistributable for Visual Studio 2017.
This package installs run-time components of Visual C++
libraries which can be used to run C++ applications 
without Visual Studio.

2) Run the gauss.bat

The game is coded to be framerate independent so a 
consistent playability without frame drop happens.
If you notice any jittering, tearing, unusually slow 
or fast, or weird stuff please tell me.

If things seem "slow" or "taking too long" something is
most likely wrong. 
Gauss is a fast AF game. 

Cheers,
_Cooper